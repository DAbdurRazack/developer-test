using System;
using System.ComponentModel.DataAnnotations;

namespace OrangeBricks.Web.Models
{
    /// <summary>
    /// Booking table equivalent C# Class
    /// </summary>
    public class Book
    {
        [Key]
        public int Id { get; set; } //Key

        [Required]
        public string BuyerUserId { get; set; } // mandatory OR not null

        public OfferStatus Status { get; set; }

        public DateTime When { get; set; }
        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

    }
}