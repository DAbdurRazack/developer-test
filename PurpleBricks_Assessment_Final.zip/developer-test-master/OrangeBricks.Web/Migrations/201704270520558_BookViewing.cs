namespace OrangeBricks.Web.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class BookViewing : DbMigration
    {
        /// <summary>
        /// New Table to store bookings on a Property
        /// This table has a FK relationship to Property table. 
        /// This establishes 1 to many relationship
        /// </summary>
        public override void Up()
        {
            CreateTable(
                "dbo.Books",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true), // booking id (primary index)
                        BuyerUserId = c.String(nullable: false), // buyer id
                        Status = c.Int(nullable: false), // pending, accepted, rejected
                        When = c.DateTime(nullable: false), // booking or viewing time
                        CreatedAt = c.DateTime(nullable: false), // create time
                        UpdatedAt = c.DateTime(nullable: false), // update time
                        Property_Id = c.Int(), // FK to Property table
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Properties", t => t.Property_Id)
                .Index(t => t.Property_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Books", "Property_Id", "dbo.Properties");
            DropIndex("dbo.Books", new[] { "Property_Id" });
            DropTable("dbo.Books");
        }
    }
}
