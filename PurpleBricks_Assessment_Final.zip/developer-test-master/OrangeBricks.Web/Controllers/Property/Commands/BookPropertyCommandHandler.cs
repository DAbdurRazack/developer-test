using System;
using System.Collections.Generic;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Property.Commands
{
    public class BookPropertyCommandHandler
    {
        private readonly IOrangeBricksContext _context;

        public BookPropertyCommandHandler(IOrangeBricksContext context)
        {
            _context = context;
        }

        public void Handle(BookPropertyCommand command)
        {
            var property = _context.Properties.Find(command.PropertyId);

            var book = new Book
            {
                When = command.When,
                Status = OfferStatus.Pending,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
                BuyerUserId = command.BuyerUserId
            };

            if (property.Books == null)
            {
                property.Books = new List<Book>();
            }
                
            property.Books.Add(book);
            
            _context.SaveChanges();
        }
    }
}