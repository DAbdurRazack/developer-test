using System;

namespace OrangeBricks.Web.Controllers.Property.Commands
{
    public class BookPropertyCommand
    {
        public int PropertyId { get; set; }

        public DateTime When { get; set; }
        public string BuyerUserId { get; set; }
    }
}