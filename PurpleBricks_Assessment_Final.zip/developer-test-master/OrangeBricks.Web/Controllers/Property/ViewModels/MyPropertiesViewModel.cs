using System.Collections.Generic;

namespace OrangeBricks.Web.Controllers.Property.ViewModels
{
    public class MyPropertiesViewModel
    {
        public List<PropertyViewModel> Properties { get; set; }
    }
}