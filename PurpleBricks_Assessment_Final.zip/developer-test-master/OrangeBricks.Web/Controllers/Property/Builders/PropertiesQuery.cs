namespace OrangeBricks.Web.Controllers.Property.Builders
{
    public class PropertiesQuery
    {
        public string Search { get; set; }
    }
}