using OrangeBricks.Web.Controllers.Property.ViewModels;
using OrangeBricks.Web.Models;
using System;

namespace OrangeBricks.Web.Controllers.Property.Builders
{
    public class BookPropertyViewModelBuilder
    {
        private readonly IOrangeBricksContext _context;

        public BookPropertyViewModelBuilder(IOrangeBricksContext context)
        {
            _context = context;
        }

        public BookPropertyViewModel Build(int id)
        {
            var property = _context.Properties.Find(id);

            return new BookPropertyViewModel
            {
                PropertyId = property.Id,
                PropertyType = property.PropertyType,
                StreetName = property.StreetName,
                When = DateTime.Now.AddDays(1) // TODO: property.SuggestedAskingPrice
            };
        }
    }
}