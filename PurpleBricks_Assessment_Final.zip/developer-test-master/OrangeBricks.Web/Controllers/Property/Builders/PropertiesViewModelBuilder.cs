using System;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Data.Entity;
using System.Linq;
using OrangeBricks.Web.Controllers.Property.ViewModels;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Property.Builders
{
    public class PropertiesViewModelBuilder
    {
        private readonly IOrangeBricksContext _context;

        public PropertiesViewModelBuilder(IOrangeBricksContext context)
        {
            _context = context;
        }

        public PropertiesViewModel Build(PropertiesQuery query, string buyerId)
        {
            var properties = _context.Properties
                .Where(p => p.IsListedForSale);

            if (!string.IsNullOrWhiteSpace(query.Search))
            {
                properties = properties.Where(x => x.StreetName.Contains(query.Search) 
                    || x.Description.Contains(query.Search));
            }

            return new PropertiesViewModel
            {
                Properties = properties
                    .Include(p => p.Offers)
                    .Include(p => p.Books)
                    .ToList()
                    .Select(p => { return MapViewModel(p, buyerId); })
                    .ToList(),
                Search = query.Search
            };
        }

        private static PropertyViewModel MapViewModel(Models.Property property, string buyerId)
        {
            var offer = property.Offers.Where(o => o.BuyerUserId == buyerId).FirstOrDefault();
            var book = property.Books.Where(o => o.BuyerUserId == buyerId).FirstOrDefault();
            return new PropertyViewModel
            {
                Id = property.Id,
                StreetName = property.StreetName,
                Description = property.Description,
                NumberOfBedrooms = property.NumberOfBedrooms,
                PropertyType = property.PropertyType,
                OfferStatus = offer == null ? (OfferStatus?)null : offer.Status,
                BookStatus = book == null ? (OfferStatus?)null : book.Status
            };
        }
    }
}