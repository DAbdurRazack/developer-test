namespace OrangeBricks.Web.Controllers.Offers.Commands
{
    public class RejectOfferCommand
    {
        public int PropertyId { get; set; }

        public int OfferId { get; set; }
    }
}