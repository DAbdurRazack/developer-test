﻿using System.Web.Mvc;
using OrangeBricks.Web.Attributes;
using OrangeBricks.Web.Controllers.Books.Builders;
using OrangeBricks.Web.Controllers.Books.Commands;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Books
{
    /// <summary>
    /// DAA: Controller Class enableing user to either accept or reject a booking request.
    /// NOTE: This is authorized to a user logged in with a role as "Seller"
    /// </summary>
    [OrangeBricksAuthorize(Roles = "Seller")] // authorized to "Seller" role only.
    public class BooksController : Controller
    {
        private readonly IOrangeBricksContext _context;

        public BooksController(IOrangeBricksContext context)
        {
            _context = context;
        }

        public ActionResult OnProperty(int id)
        {
            var builder = new BooksOnPropertyViewModelBuilder(_context);
            var viewModel = builder.Build(id);

            return View(viewModel);
        }

        [HttpPost]        
        public ActionResult Accept(AcceptBookCommand command)
        {
            var handler = new AcceptBookCommandHandler(_context);

            handler.Handle(command);

            return RedirectToAction("OnProperty", new { id = command.PropertyId });
        }

        [HttpPost]
        public ActionResult Reject(RejectBookCommand command)
        {
            var handler = new RejectBookCommandHandler(_context);

            handler.Handle(command);

            return RedirectToAction("OnProperty", new { id = command.PropertyId });
        }
    }
}