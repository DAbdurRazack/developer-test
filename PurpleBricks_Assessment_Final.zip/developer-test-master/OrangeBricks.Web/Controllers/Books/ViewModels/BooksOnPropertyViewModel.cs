using System;
using System.Collections.Generic;

namespace OrangeBricks.Web.Controllers.Books.ViewModels
{
    /// <summary>
    /// DAA: Bookings on the property View Model Class
    /// </summary>
    public class BooksOnPropertyViewModel
    {
        public string PropertyType { get; set; }
        public int NumberOfBedrooms{ get; set; }
        public string StreetName { get; set; }
        public bool HasBooks { get; set; }
        public IEnumerable<BookViewModel> Books { get; set; } // Collection of Bookings to property (1 to many)
        public int PropertyId { get; set; }
    }

    /// <summary>
    /// DAA: Booking View Model Class
    /// </summary>
    public class BookViewModel
    {
        public int Id;
        public DateTime When { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsPending { get; set; }
        public string Status { get; set; }
    }
}