namespace OrangeBricks.Web.Controllers.Books.Commands
{
    /// <summary>
    /// DAA: Command Class for Accepting a Booking on a Property
    /// </summary>
    public class AcceptBookCommand
    {
        /// <summary>
        /// Property ID
        /// </summary>
        public int PropertyId { get; set; }

        /// <summary>
        /// Booking ID
        /// </summary>
        public int BookId { get; set; }
    }
}