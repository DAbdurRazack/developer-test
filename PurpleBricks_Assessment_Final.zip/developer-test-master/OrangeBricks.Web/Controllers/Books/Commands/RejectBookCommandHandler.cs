using System;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Books.Commands
{
    /// <summary>
    /// DAA: Booking Command Handler Class for an Reject action
    /// </summary>
    public class RejectBookCommandHandler
    {
        private readonly IOrangeBricksContext _context;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context">IOrangeBricksContext</param>
        public RejectBookCommandHandler(IOrangeBricksContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Saves rejected Booking on a property.
        /// </summary>
        /// <param name="command">RejectBookCommand</param>
        public void Handle(RejectBookCommand command)
        {
            var book = _context.Books.Find(command.BookId);

            book.UpdatedAt = DateTime.Now;
            book.Status = OfferStatus.Rejected;

            _context.SaveChanges();
        }
    }
}