using System;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Books.Commands
{
    /// <summary>
    /// DAA: Booking Command Handler Class for an Accept action
    /// </summary>
    public class AcceptBookCommandHandler
    {
        private readonly IOrangeBricksContext _context;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context">IOrangeBricksContext</param>
        public AcceptBookCommandHandler(IOrangeBricksContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Saves accepted Booking on a property
        /// </summary>
        /// <param name="command">AcceptBookCommand</param>
        public void Handle(AcceptBookCommand command)
        {
            var book = _context.Books.Find(command.BookId);

            book.UpdatedAt = DateTime.Now;
            book.Status = OfferStatus.Accepted;

            _context.SaveChanges();
        }
    }
}