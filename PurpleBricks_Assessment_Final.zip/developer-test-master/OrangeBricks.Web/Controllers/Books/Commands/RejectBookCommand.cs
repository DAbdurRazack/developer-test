namespace OrangeBricks.Web.Controllers.Books.Commands
{
    /// <summary>
    /// DAA: Command Class for Rejecting a Booking on a Property
    /// </summary>
    public class RejectBookCommand
    {
        /// <summary>
        /// Property ID
        /// </summary>
        public int PropertyId { get; set; }

        /// <summary>
        /// Booking ID
        /// </summary>
        public int BookId { get; set; }
    }
}