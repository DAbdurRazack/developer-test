﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using OrangeBricks.Web.Controllers.Books.ViewModels;
using OrangeBricks.Web.Models;

namespace OrangeBricks.Web.Controllers.Books.Builders
{
    /// <summary>
    /// DAA: Class BooksOnPropertyViewModelBuilder
    /// </summary>
    public class BooksOnPropertyViewModelBuilder
    {
        private readonly IOrangeBricksContext _context;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context">IOrangeBricksContext</param>
        public BooksOnPropertyViewModelBuilder(IOrangeBricksContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Returns Booking on a property
        /// </summary>
        /// <param name="id">Booking ID; int</param>
        /// <returns></returns>
        public BooksOnPropertyViewModel Build(int id)
        {
            var property = _context.Properties
                .Where(p => p.Id == id)
                .Include(x => x.Books)
                .SingleOrDefault();

            var books = property.Books ?? new List<Book>();

            return new BooksOnPropertyViewModel
            {
                HasBooks = books.Any(),
                Books = books.Select(x => new BookViewModel
                {
                    Id = x.Id,
                    When = x.When,
                    CreatedAt = x.CreatedAt,
                    IsPending = x.Status == OfferStatus.Pending,
                    Status = x.Status.ToString()
                }),
                PropertyId = property.Id, 
                PropertyType = property.PropertyType,
                StreetName = property.StreetName,
                NumberOfBedrooms = property.NumberOfBedrooms
            };
        }
    }
}